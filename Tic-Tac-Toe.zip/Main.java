import java.util.Scanner;

class Main {
  //Variables needed to be used in all methods
  static String[][] board = new String[3][3];
  static int turn = 0;

  public static void main(String[] args) {
    makeBoard();
    
    while (true) { //Do this forever until someone wins
      if (checkWin()) { 
        //If someone wins, do this 
        System.out.println();
        System.out.println("WINNER!");
        printBoard();
        System.exit(0);
      }

      if (checkTie()) {
        //If it's a tie, do this
        System.out.println();
        System.out.println("CAT'S GAME!");
        printBoard();
        System.exit(0);
      }

      //Stuff we want to do every turn
      System.out.println("\033[H\033[2J"); //Clears the console
      System.out.println("~ VAUGHN'S ALL AMERICAN TIC TAC TOE ~");
      System.out.println();
      makeTable();
      System.out.println();

      if (turn % 2 == 0) {
        System.out.println("X TURN");
      }
      else {
        System.out.println("O TURN");
      }
      printBoard();
      updateBoard();
      turn++;
    }
  }

  //Standard input method, docs available at https://repl.it/@LordOnO/Useful-Methods#Main.java
  public static String input(String str) {
    Scanner scan = new Scanner(System.in);
    System.out.print(str);
    return scan.nextLine();
  }

  //Makes the table with coordinates
  public static void makeTable() {
    for (int a = 0; a < 3; a++) {
      for (int b = 0; b < 3; b++) {
        System.out.format("%d%d ", a, b);
      }
      System.out.println();
    }
  }

  //Updates the board with the player's moves
  public static void updateBoard() {
    int x = 0; //Row
    int y = 0; //Column

    while (true) { //All the loops (Ends on 106)
      while (true) { //First three (Ends on 97)
        while (true) { //Just itself (Ends on 79)
          x = Integer.valueOf(input("Row: "));
          if (x > 2) {
            System.out.println("Sorry, please try again");
          }
          else {
            break;
          }
        }

        while (true) { 
          y = Integer.valueOf(input("Column: "));
          if (y > 2) {
            System.out.println("Sorry, please try again");
          }
          else {
            break;
          }
        }

        if (board[x][y] != "-  ") {
          System.out.println("Sorry, please try again");
        }
        else {
          break;
        }
      }

      if (turn % 2 == 0) {
        board[x][y] = "X  ";
      }
      else {
        board[x][y] = "O  ";
      } 
      break;
    }
  }

  //Cycles through the board using for loops, just used once at the beginning to create the blank board
  public static void makeBoard() {
    for (int x = 0; x < 3; x++) {
      for (int y = 0; y < 3; y++) {
        board[x][y] = "-  ";
      }
    } 
  }

  //Same as above, just prints the board instead of making it
  public static void printBoard() {
    for (int x = 0; x < 3; x++) {
      for (int y = 0; y < 3; y++) {
        System.out.print(board[x][y]);
      }
      System.out.println();
    }
  }

  public static boolean checkRow(int x) {
    int y = 0; //Column
    while (true) {
        //This section checks the horizontal
        while (y != 2) { //While we haven't reached the last column...
          if (board[x][y] != "-  " && board[x][y] == board[x][y + 1]) { //If the space we're checking is equal to the next space to the right
            y++; //Next column
            if (y == 2) { //If we got to the end, we know the whole row is the same, return true
              return true;
            }
          } 
          else { //If the space to the right isn't the same, no point checking the rest. Break
            break;
          }
        }

        //This section checks the diagonals
        while (true) {
          //Because there are only two possible diagonals in the game, they are hard coded
          if (board[1][1] != "-  " && board[1][1] == board[0][0] && board[1][1] == board[2][2]) {
            return true;
          }
          else if (board[1][1] != "-  " && board[1][1] == board[2][0] && board[1][1] == board[0][2]) {
            return true;
          }
          else {
            break;
          }
        }

      return false; //If we got to the end, then nothing else is true. Return false
    }
  }

  public static boolean checkWin() {
    int i = 0;

    //Increments through the rows and calls checkRow() to check them
    while (true) {
      if (checkRow(i)) {
        return true;
      }
      else {
        if (i != 2) { //If we've still got rows to check, i++
          i++;
        }
        else { //If we've gotten to then end, that means nothing is true. Return false
          return false;
        }
      }
    }
  }

  public static boolean checkTie() {
    int i = 0;

    //Cycles through the board, adds 1 to int i everytime it finds a space that isn't "-  " (blank). If it finds a blank space it sets i = 0 and breaks. If it get through the entire board it breaks and int i should be equal to 9
    while (true) {
      for (int a = 0; a < 3; a++) {
        for (int b = 0; b < 3; b++) {
          if (board[a][b] != "-  ") {
            i++;
          }
          else {
            i = 0;
            break;
          }
        }
      }
      break;
    }

    //If int i = 9, then we know all the spaces are occupied, so return true. Else, we know there is at least 1 blank  space, so return false
    if (i == 9) {
      return true;
    }
    else {
      return false;
    }
  }
}