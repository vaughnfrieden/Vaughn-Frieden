/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package encryption;

import java.util.Scanner;

/*
Vaughn's Big List of Things
#1 - Test all encryption/decryption algorithms against a test string (Hello! Hello! #Lol)
    - They also have to be readable by a 3rd party translator
#2 - Switch while loops to for loops
#3 - Write out comments and documentation
#4 - Compile to .exe
#5 - Get on google play store?
#6 - Collect underpants
#7 - ...?
#8 - Profit!
*/


public class Encryption {
    static String asciiStr;
    static String binaryStr;
    static String azStr;
    static String morseStr;
    static String bashStr;
    static String caesarStr;
    static String userInput;
    
    public static String input(String str) {
        Scanner scan = new Scanner(System.in);
        System.out.print(str);
        return scan.nextLine();
    }

    public static void main(String[] args) {
        System.out.println("#1 = Encrypt");
        System.out.println("#2 = Decrypt");
        userInput = input("> ");
        
        switch (userInput) {
            case "1":
                encrypt();
                break;
            case "2":
                decrypt();
                break;
            default:
                System.out.println("Sorry, something has gone wrong.");
        }
    }
    
    public static void encrypt() {
        System.out.println();
        System.out.println("#1 = ASCII");
        System.out.println("#2 = Binary");
        System.out.println("#3 = A1Z26");
        System.out.println("#4 = Morse Code");
        System.out.println("#5 = Atbash");
        System.out.println("#6 = Caesar Cipher");
        userInput = input("> ");
        
        
        switch (userInput) {
            case "1":
                asciiStr = input("Encrypt using ASCII: ");
                System.out.println(toAscii(asciiStr, true));
                break;
            case "2":
                binaryStr = input("Encrypt using Binary: ");
                System.out.println(toBinary(binaryStr));
                break;
            case "3":
                azStr = input("Encrypt using A1Z26: ");
                System.out.println(toAZ(azStr, true));
                break;
            case "4":
                morseStr = input("Encrypt using Morse Code: ");
                System.out.println(toMorse(morseStr));
                break;
            case "5":
                bashStr = input("Encrypt using Atbash: ");
                System.out.println(toBash(bashStr));
                break;
            case "6":
                caesarStr = input("Encrypt using the Caesar Cipher: ");
                System.out.println(toCaesar(caesarStr));
                break;
            default:
                System.out.println("Sorry, something has gone wrong.");
                break;
        }
    }
    
    @SuppressWarnings("empty-statement") // Suppress the empty statement warning in NetBeans
    public static String decrypt() {
        System.out.println();
        System.out.println("#1 = ASCII");
        System.out.println("#2 = Binary");
        System.out.println("#3 = A1Z26");
        System.out.println("#4 = Morse Code");
        System.out.println("#5 = Atbash");
        System.out.println("#6 = Caesar Cipher");
        userInput = input("> ");
        
        
        switch (userInput) {
            case "1":
                asciiStr = input("Decrypt using ASCII: ");
                System.out.println(fromAscii(asciiStr, true));
                break;
            case "2":
                binaryStr = input("Decrypt using Binary: ");
                System.out.println(fromBinary(binaryStr));
                break;
            case "3":
                azStr = input("Decrypt using A1Z26: ");
                System.out.println(fromAZ(azStr, true));
                break;
            case "4":
                morseStr = input("Decrypt using Morse Code: ");
                System.out.println(fromMorse(morseStr));
                break;
            case "5":
                bashStr = input("Decrypt using Atbash: ");
                System.out.println(fromBash(bashStr));
                break;
            case "6":
                caesarStr = input("Decrypt using the Caesar Cipher: ");
                System.out.println(fromCaesar(caesarStr));
                break;
            default:
                System.out.println("Sorry, something has gone wrong.");
                break;
        }
        return null;
    }
    
    
    @SuppressWarnings("empty-statement") // Suppress the empty statement warning in NetBeans
    public static String toAscii(String asciiStr, boolean asciiSpace) {
        int i = 0; // Interable.
        String asciiResult = "";
        
        while (i < asciiStr.length()) {
            int iTemp = 0;
            char cTemp;
            String lenTemp;
            
            cTemp = asciiStr.charAt(i); // cTemp is equal to the char we're working on.
            iTemp = iTemp + cTemp; // Implicit conversion of char (cTemp) -> int (iTemp) which now equals the ASCII value.
            lenTemp = Integer.toString(iTemp); // int (iTemp) -> string. We have to test the length before we append it.
            
            /*
            In order for the text to be translated back into proper ASCII, 
            every character needs a three diget value. If it's two digits, we add a zero.
            */
            if (lenTemp.length() == 2) { 
                asciiResult = asciiResult + "0";
            }
            asciiResult = asciiResult + Integer.toString(iTemp); // Appending the character the asciiResult string.
            if (asciiSpace) {
                asciiResult = asciiResult + " "; // Adding a space in between characters to make it readable.
            }
            i++;
        }
        return asciiResult;
    }
    
    @SuppressWarnings("empty-statement") // Suppress the empty statement warning in NetBeans
    public static String fromAscii(String asciiStr, boolean asciiSpace) {
        String asciiResult = "";
        String temp = "";
        asciiStr = asciiStr + " ";
        
        for (int i = 0; i < asciiStr.length();) {
            if (asciiStr.charAt(i) != ' ') {
                temp = temp + asciiStr.charAt(i);
            }
            else {
                if (temp.charAt(0) == '0') {
                    temp = temp.replace("0", "");
                    //System.out.println("New temp: " + temp);
                }
                asciiResult = asciiResult + (char) (Integer.parseInt(temp));               
                temp = "";
            }
            i++;
        }
        return asciiResult; 
    }
    
    @SuppressWarnings("empty-statement") // Suppress the empty statement warning in NetBeans
    public static String toBinary(String binaryStr) {
        int i = 0;
        String binaryResult = "";
        int temp;
        
        while (i < binaryStr.length()) {
            temp = Integer.parseInt(toAscii(String.valueOf(binaryStr.charAt(i)), false));
            binaryResult = binaryResult + Integer.toBinaryString(temp);
            binaryResult = binaryResult + " ";
            i++;
        }
        return binaryResult;
    }
    
    public static String fromBinary(String binaryStr) {
        String binaryResult = "";
        String temp = "";
        binaryStr = binaryStr + " ";
        
        //notes, take each byte (8 bits, 1's & 0's) and convert it sepreately, before adding to the result and moving
        //on to next bit and doing the same. If you try and do the whole string you get a number format exception
        for (int i = 0; i < binaryStr.length(); i++) {
            if (binaryStr.charAt(i) != ' ') {
                temp = temp + binaryStr.charAt(i);
            }
            else {
                binaryResult = binaryResult + fromAscii(Integer.toString(Integer.parseInt(temp, 2)), true);             
                temp = "";
            }
        }
        return binaryResult;
    }
    
    @SuppressWarnings("empty-statement") // Suppress the empty statement warning in NetBeans
    public static String toAZ(String azStr, boolean azSpace) {
        int i = 0; // Interable.
        String azResult = "";
        azStr = azStr + " ";
        
        while (i < azStr.length()){
            //               Integer  -> Ascii  -> String  -> (Current char) |No space|
            int asciiTemp = Integer.parseInt(toAscii(String.valueOf(azStr.charAt(i)), false));
            
            if (asciiTemp <= 64 && asciiTemp != 32)  { // If the ASCII value is 0 - 64, and not a space, don't append.
                azResult = azResult + azStr.charAt(i);
            }
            else if (asciiTemp == 32) {
                azResult = azResult + azStr.charAt(i);
            }
            else if (asciiTemp >= 91 && asciiTemp <= 96) { // If the ASCII value is 91 - 96, don't append.
                azResult = azResult + azStr.charAt(i);
            }
            else if (asciiTemp >= 123) { // If the ASCII value is >123, don't append.
                azResult = azResult + azStr.charAt(i);
            }
            else {
                //                          String -> Integer (% by 32) -> Ascii -> String -> (Current char) |No space|
                azResult = azResult + Integer.toString(Integer.parseInt(toAscii(String.valueOf(azStr.charAt(i)), false)) % 32);
            }
            
            /*
            If we want a space, and the character isnt a space, and its not the last char and the 
            next character isnt a space, add a - to seperate the chars.
            */
            if (azSpace && asciiTemp != 32 && i != azStr.length() && azStr.charAt(i) != '#') {
                if (azStr.charAt(i + 1) == ' ') {
                    ;
                }
                else {
                    azResult = azResult + "-";
                }
            }
            i++;
        }
        return azResult;
    }
    
    
    @SuppressWarnings("empty-statement") // Suppress the empty statement warning in NetBeans
    public static String fromAZ(String azStr, boolean azSpace) {
        String[] alpha = {"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"};
        String azResult = "";
        azStr = azStr + "-";
        String temp = "";
        int asciiTemp = 0;
        
        /* 
        The input "I am" with throw and error because temp doesnt convert after the "I" (9) and keeps going, 
        gets the next character "a" (1) and tries to convert 91, 91 % 32 = 27. 27 - 1 = 26. There is no 26th
        entry in the alpha array (zero based) so it throws a array out of bounds exception.
        */
        
        
        for (int i = 0; i < azStr.length(); i++) {
            asciiTemp = Integer.parseInt(toAscii(String.valueOf(azStr.charAt(i)), false)); // the ascii value of char(i)
            
            if (asciiTemp != 45 && (asciiTemp >= 48 && asciiTemp <= 57)) { //if not - && a number
                temp = temp + azStr.charAt(i); //add to temp, to be converted
                System.out.println("temp #1: " + temp);
            }
            else if (asciiTemp != 45 && (asciiTemp <= 48 || asciiTemp >= 57)) { // if not - && not a number
                azResult = azResult + azStr.charAt(i); //add to result, NOT to be converted
            }
            else if (asciiTemp == 45 || i == azStr.length()) { // if ' ', we know we've got the next number, convert it and reset
                System.out.println("i: " + i);
                System.out.println("asciiTemp: " + asciiTemp);
                System.out.println("azStr.length(): " + azStr.length());
                if (temp.length() != 0) {
                    azResult = azResult + alpha[(Integer.parseInt(temp) - 1) %32];
                    System.out.println("azResult: " + azResult);
                    System.out.println("temp #2: " + temp);
                    temp = "";
                }
                else {
                    azResult = azResult + " ";
                }
            }
            System.out.println("i: " + i);
        }
        return azResult;
    }
    
    @SuppressWarnings("empty-statement") // Suppress the empty statement warning in NetBeans
    public static String toMorse(String morseStr) {
        // Each more code letter, in a string array.
        String[] morseCode = {".-","-...","-.-.","-..",".","..-.","--.","....","..",".---","-.-",".-..","--","-.","---",".--.","--.-",".-.","...","-","..-","...-",".--","-..-","-.--","--.."};
        int i = 0; // Interable.
        String morseResult = ""; 
                
        while (i < morseStr.length()) { 
            while (i < morseStr.length()) {
                //                  Integer  -> Ascii  -> String  -> (Current char) |No space|
                int temp = Integer.parseInt(toAscii(String.valueOf(morseStr.charAt(i)), false));
                
                if (temp <= 64)  {  // If the ASCII value is 0 - 64, don't convert.
                    morseResult = morseResult + morseStr.charAt(i);
                }
                else if (temp >= 91 && temp <= 96) {  // If the ASCII value is 91 - 96, don't convert
                    morseResult = morseResult + morseStr.charAt(i);
                }
                else if (temp >= 123) { // If the ASCII value is >123, don't convert
                    morseResult = morseResult + morseStr.charAt(i);
                }
                else {
                    //                                              Integer -> Alpha -> String -> (Current char)|No space|
                    morseResult = morseResult + morseCode[Integer.parseInt(toAZ(String.valueOf(morseStr.charAt(i)), false)) - 1];
                }                
                morseResult = morseResult + " "; // We always want to add a space for readability.
                i++;
                
            }
        }
        return morseResult; 
    }
    
    public static String fromMorse(String morseStr) {
        String[] morseCode = {".-","-...","-.-.","-..",".","..-.","--.","....","..",".---","-.-",".-..","--","-.","---",".--.","--.-",".-.","...","-","..-","...-",".--","-..-","-.--","--.."}; 
        String[] alpha = {"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"};
        int asciiTemp = 0;
        int x = 0;
        morseStr = morseStr + " ";
        String temp = "";
        String morseResult = "";

        for (int i = 0; i < morseStr.length(); i++) {
            //                   Integer  -> Ascii  -> String  -> (Current char) |No space|
            asciiTemp = Integer.parseInt(toAscii(String.valueOf(morseStr.charAt(i)), false)); // the ascii value of char(i)

            if (asciiTemp != 32 && (asciiTemp == 45 || asciiTemp == 46)) { //if not ' ' && - or .
                temp = temp + morseStr.charAt(i); //add to temp, to be converted
                //System.out.println("Temp: " + temp);
            }
            if (asciiTemp != 32 && (asciiTemp != 45 && asciiTemp != 46)) {
                morseResult = morseResult + morseStr.charAt(i);
            }
            else if (asciiTemp == 32) { // if ' ', we know we've got the full character, convert it and reset
                if (temp.length() != 0) {
                    for (String s : morseCode) {
                        if (s.equals(temp)) {
                            morseResult = morseResult + alpha[x];
                            //System.out.println("morseResult: " + morseResult);
                            temp = ""; 
                            x = 0;
                            break;
                        }
                        x++;
                    }
                }
                else {
                    morseResult = morseResult + " ";
                }
            }
        }
        return morseResult;
    }
    
    @SuppressWarnings("empty-statement") // Suppress the empty statement warning in NetBeans
    public static String toBash(String bashStr) {
        // Alphabet backwards
        char[] alpha_back = {'z','y','x','w','v','u','t','s','r','q','p','o','n','m','l','k','j','l','h','g','f','e','d','c','b','a'};
        int i = 0; 
        String bashResult = "";
        
        while (i < bashStr.length()) {
            //                  Integer  -> Ascii  -> String  -> (Current char) |No space|
            int temp = Integer.parseInt(toAscii(String.valueOf(bashStr.charAt(i)), false));
            
            if (temp <= 64)  {  // If the ASCII value is 0 - 64, append without converting.
                bashResult = bashResult + bashStr.charAt(i);
            }
            else if (temp >= 91 && temp <= 96) { // If the ASCII value is 91-96, append without converting.
                bashResult = bashResult + bashStr.charAt(i);
            }
            else if (temp >= 123) { // If the ASCII value is >123, append without converting.
                bashResult = bashResult + bashStr.charAt(i);
            }
            else {
                if (Character.isUpperCase(bashStr.charAt(i))) { // If the character is uppercase, append an uppercase character.
                    //                            Uppercase -> Value in Array -> Integer (-1) -> Alpha -> String  -> (Current char) |No space|
                    bashResult = bashResult + Character.toUpperCase(alpha_back[Integer.parseInt(toAZ(String.valueOf(bashStr.charAt(i)), false)) - 1]);
            }
                else {
                    //                   Value in Array -> Integer (-1) -> Alpha -> String  -> (Current char) |No space|                    
                    bashResult = bashResult + alpha_back[Integer.parseInt(toAZ(String.valueOf(bashStr.charAt(i)), false)) - 1];
                }
            }
            i++;
        }
        return bashResult;
    }
    
    @SuppressWarnings("empty-statement") // Suppress the empty statement warning in NetBeans
    public static String fromBash(String bashStr) {
        char[] alpha_back = {'z','y','x','w','v','u','t','s','r','q','p','o','n','m','l','k','j','l','h','g','f','e','d','c','b','a'};
        String[] alpha = {"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"};
        String bashResult = "";
        int x = 0;
        
        for (int i = 0; i < bashStr.length();) { //for each char in bashStr
            int asciiTemp = Integer.parseInt(toAscii(String.valueOf(bashStr.charAt(i)), false));
            for (char c : alpha_back) {
                if ((asciiTemp >= 0 && asciiTemp <= 64) || (asciiTemp >= 91 && asciiTemp <= 96) || (asciiTemp >= 123)) {
                    bashResult = bashResult + bashStr.charAt(i);
                    i++;
                    break;
                }
                bashStr = bashStr.toLowerCase();
                if (c == bashStr.charAt(i)) {
                    bashResult = bashResult + alpha[x];
                    i++;
                    x = 0;
                    break;
                }
                else {
                    x++;
                }  
            }
        }
        return bashResult;    
    }

    @SuppressWarnings("empty-statement") // Suppress the empty statement warning in NetBeans
    public static String toCaesar(String caesarStr) {
        int i = 0;
        String caesarResult = "";
        char[] alpha_3 = {'d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','a','b','c'};
        
        while (i < caesarStr.length()) {
            int temp = Integer.parseInt(toAscii(String.valueOf(caesarStr.charAt(i)), false)); // the ascii value of char(i)
            if (temp <= 64)  { // If the ASCII value is 0 - 64, append without converting.
                caesarResult = caesarResult + caesarStr.charAt(i);
            }
            else if (temp >= 91 && temp <= 96) { // If the ASCII value is 91 - 96, append without converting.
                caesarResult = caesarResult + caesarStr.charAt(i);
            }
            else if (temp >= 123) { // If the ASCII value is >123, append without converting.
                caesarResult = caesarResult + caesarStr.charAt(i);
            }
            else {
                if (Character.isUpperCase(caesarStr.charAt(i))) { // If the character is uppercase, append an uppercase character
                    //                               Uppercase -> Value in Array -> Integer (-1) -> Alpha -> String  -> (Current char) |No space|
                    caesarResult = caesarResult + Character.toUpperCase(alpha_3[Integer.parseInt(toAZ(String.valueOf(caesarStr.charAt(i)), false)) - 1]);
                }
                else {
                    //                      Value in Array -> Integer (-1) -> Alpha -> String  -> (Current char) |No space|
                    caesarResult = caesarResult + alpha_3[Integer.parseInt(toAZ(String.valueOf(caesarStr.charAt(i)), false)) - 1];
                }
            }
            i++;
        }
        return caesarResult;   
    }
    
    public static String fromCaesar(String caesarStr) {
        String[] alpha = {"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"};
        char[] alpha_3 = {'d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','a','b','c'};
        String caesarResult = "";
        int x = 0;
        
        for (int i = 0; i < caesarStr.length();) { //for each char in bashStr
            int asciiTemp = Integer.parseInt(toAscii(String.valueOf(caesarStr.charAt(i)), false));
            for (char c : alpha_3) {
                if ((asciiTemp >= 0 && asciiTemp <= 64) || (asciiTemp >= 91 && asciiTemp <= 96) || (asciiTemp >= 123)) {
                    caesarResult = caesarResult + caesarStr.charAt(i);
                    i++;
                    break;
                }
                caesarStr = caesarStr.toLowerCase();
                if (c == caesarStr.charAt(i)) {
                    caesarResult = caesarResult + alpha[x];
                    i++;
                    x = 0;
                    break;
                }
                else {
                    x++;
                }  
            }
        }
        return caesarResult;    
    }
}