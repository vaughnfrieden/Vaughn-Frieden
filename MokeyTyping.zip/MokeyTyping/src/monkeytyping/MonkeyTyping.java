package monkeytyping;

import java.util.Random;
import java.util.Scanner;
import java.util.Arrays;

public class MonkeyTyping {
    public static void main(String[] args) {
        String[] alpha = {"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"," "};
        String result = ""; //The result (from the monkeys)
        String allowed = "abcdefghijklmnopqrstuvwxyz";
        String word = input("Please Enter a String (English Alphabet Only): ");
        word = word.toLowerCase();
        String testStr = "";
        int iRand; // Line 8 & 9 just prep for random int
        int tries = 0;
        int chance = (int) Math.pow((allowed.length() + 1), word.length());
        Random rand = new Random();
        double percentChance = 0.111111111111111;
        
        
        
        //SPACE NOT WORKING??? "hello i" doesn't work...
        
        
        for (int i = 0; i < word.length(); i++) {
            if (allowed.contains(Character.toString(word.charAt(i)))) {
                ;
            }
            else {
                System.out.println("Sorry, please try again.");
                System.exit(0);
                break;
            }
        }

        for (int i = 0; i < word.length(); i++) {
            iRand = rand.nextInt(26);
            result = result + alpha[iRand];
            tries++;
            if (result.length() == word.length()) {
                if (result.equals(word)) {
                    //testStr = String.format("Congratulation! It ONLY took %d tries! Wow, world record! ;)", tries);
                    System.out.format("Congratulation! It ONLY took %d tries! Wow, world record! ;) %n", tries);
                    //testStr = String.format("The probability of getting that combination was 1/%d or %f", chance, percentChance);
                    System.out.format("The probability of getting that combination was 1/%d %n", chance);
                    break;
                }
                else {
                    i = -1;
                    //System.out.println(result);
                    result = "";
                }
            }
        }
    }
    
    public static String input(String str) {
        Scanner scan = new Scanner(System.in);
        System.out.print(str);
        return scan.nextLine();
    } 
}
